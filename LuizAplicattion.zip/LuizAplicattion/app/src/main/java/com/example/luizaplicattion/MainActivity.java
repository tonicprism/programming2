package com.example.luizaplicattion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
// ele extende do AppCompatActivity
public class MainActivity extends AppCompatActivity{

    @Override
    // quando eu instancio o MainActivity;tela nem ainda aparece - background work
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //mensagem na tela; possui dois parâmetros: tela onde será aplicada a mensagem, a mensagem, e tempo;
        // logo depois eu ponho um show para mostrar na tela
        Toast.makeText(MainActivity.this, "A activity main foi criada. (onCreate)",
        Toast.LENGTH_SHORT).show();

        //método que define a tela principal/define qual será o layout xml
        setContentView(R.layout.activity_main);

        // criando um botão e pegando ele pelo ID;
        final Button button = (Button)findViewById(R.id.buttonOnClick);
        // criando um textedit e pegando ele pelo ID;
        final EditText editText = (EditText)findViewById(R.id.editText);
        // PEGANDO A VIEWTEXT
        final TextView teste = (TextView) findViewById(R.id.teste);
        // Pegando o PROGRESSBAR
        final ProgressBar pBar = (ProgressBar) findViewById(R.id.progressBar);
        pBar.setVisibility(View.INVISIBLE);
        //agora crio o evento listener/função lambda
        button.setOnClickListener(new View.OnClickListener(){
            // função que será chamada
            public void onClick(View v){
                CEPAsyncTask task = new CEPAsyncTask(pBar, button);
                task.execute(editText.getText().toString());
            }
        });



    }
    // quando a tela está pronta para ser desenhada
    protected void onStart(){
        super.onStart();
        Toast.makeText(MainActivity.this, "A activity foi iniciada. onStart", Toast.LENGTH_LONG).show();
    }
    // quando a tela restarta
    protected void onRestart(){
        super.onRestart();
        Toast.makeText(MainActivity.this, "A activity foi iniciada. onRestart", Toast.LENGTH_LONG).show();
    }
    // quando a tela volta do resumo
    protected void onResume(){
        super.onResume();
        Toast.makeText(MainActivity.this, "A activity foi iniciada. onResume", Toast.LENGTH_LONG).show();
    }
    // quando a tela para
    protected void onStop(){
        super.onStop();
        Toast.makeText(MainActivity.this, "A activity foi iniciada. onStop", Toast.LENGTH_LONG).show();
    }
    // destroio a aplicação
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(MainActivity.this, "A activity foi iniciada. onDestroy", Toast.LENGTH_LONG).show();

    }
}
