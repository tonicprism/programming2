package com.example.luizaplicattion;

import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class CEPAsyncTask extends AsyncTask<String, Void, String> {
    private ProgressBar pBar;
    private Button button;

    // constructor
    public CEPAsyncTask(ProgressBar pBar, Button button){
        this.pBar = pBar;
        this.button = button;
    }

    // ação a ser executada antes da tarefa
    protected void onPreExecute(){
        super.onPreExecute();
        this.button.setEnabled(false);
        this.pBar.setVisibility(View.VISIBLE);
    }

    // o que será feito no background
    @Override
    protected String doInBackground(String... params) {
        String uri = "http://viacep.com.br/ws/" + params[0]+"/json/";
        return HttpRequestor.get(uri);
    }
    protected void onPostExecute(String result){
        super.onPostExecute();
    }
}
